package com.example.videoonapp;

import androidx.appcompat.app.AppCompatActivity;

import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.MediaController;
import android.widget.VideoView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        VideoView video=findViewById(R.id.simlevideo);


        video.setVideoPath("android.resource://"+getPackageName()+"/"+R.raw.video);
        MediaController control=new MediaController(this);
        video.setMediaController(control);

        control.setAnchorView(video);
        video.start();


    }
}
